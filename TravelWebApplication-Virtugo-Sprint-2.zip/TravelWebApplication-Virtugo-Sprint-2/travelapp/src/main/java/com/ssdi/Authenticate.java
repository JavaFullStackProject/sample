package com.ssdi;

public interface Authenticate {

}
