package com.ssdi;

public interface Create {

}
